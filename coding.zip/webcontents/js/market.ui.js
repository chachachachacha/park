function FeatureInfoLoad(feature){
    var postdata={
        
        'action':'selectmarket',
        'cam_id':feature.get('cam_id')
        
    };
    $.ajax({
        url:"market.do"
        cache:false,
        data:postdata,
    }).done(function(data){
        $("#FeatureInfo").html(data);
        $("#FeatureInfo").show();
    });
    
}
function FeatrueInfoWndClose(){
    
    $("#FeatureInfo").hide();
    $("#FeatureInfo h3").text("-");
    $("#FeatureInfo td").text("-");
}