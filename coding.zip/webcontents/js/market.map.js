var bounds = ol.proj.transformExtent([126,43,128,32],'EPSG:4326','EPSG3857');

var geojsonFormat=new ol.format.GeoJSON();

window.loadFeatures = function(response){
   vectorSourse.addFeatures(geojsonFormat.readFeatures(response));
}
var vectorSourse = new ol.source.Vector({
   loader:function(extent,resolution,projection){
      var url = 'http://localhost:8080/geoserver/MarketWS/ows?service=WFS&'+
		'version=1.1.0&request=GetFeature&typename=MarketWS:tbl_coor&'+
 		'outputFormat=text/javascript&format_options=callback:loadFeatures'+
		'&srcname=EPSG:3857&bbox=' + extent.join(',')+',EPSG:3857'
	    $.ajax(
		url:url,
		dataType:'json'
	     	jsonp:false
	       });
	      },
	      strategy:ol.loadingstrategy.tile(ol.tilegrid.createXYZ({
		maxZoom:19
		})
	      });

	//WMS의 sourse설정
	
	var imagesourceWMS = new ol.source.ImageWMS({
	  ratio:1,
	  url: 'http://localhost:8080/geoserver/MarketWS/wms',
	  params:{'FORMAT':'image/png',LAYERS:'MarketWS:tbl_coor'}
	});

	var osmlayer = new ol.layer.Tile({
	   sourse:new ol.source.OSM()
	});

	var pMarketsiteWFSlayer = new ol.layer.Vector({
	   source:vectorSource
	});

	//위에서 설정한 source입력, source를 포함하면 untiled가 하나의 레이어가 됨
	var untiled = new ol.layer.image({
	   source:imagesourceWMS
	});
	//마지막으로 설정한 레이어와 view 등 map에 입력, map에 지금까지 설정한 모든 지도의 정보가 들어있음.
	var map = new ol.map({
	  controls: ol.control.defaults({
	    attribution:false
	});

	target:'map',
	layers:[osmlayer,pMarketsiteWFSlayer,untiled]
	});
	//화면 크기에 알맞게 지도 띄우기
	map.getView().fit(bounds,map.getSize()); 

	map.on('singleclick',function(evt){
	  displayFeatureInfo(evt.pixel);
	});

	var displayFeatureInfo = function(pixel){
	  var feature = map.forEachFeatureAtPixel(pixel,function(feature,layer){
	    return feature;
	});

	if(feature){
	  FeatureInfoLoad(feature);
	}
	else{
	  FeatureInfoWndClose();
	}
       };
	